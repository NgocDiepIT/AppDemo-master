package com.example.appdemo.network;

public class APIStringRoot {

    static final String API_ROOT = "https://hubbook.herokuapp.com";

    static final String LOGIN = "/api/user/login";

    static final String HEADER = "Content-Type: application/json; charset=UTF-8";
}
