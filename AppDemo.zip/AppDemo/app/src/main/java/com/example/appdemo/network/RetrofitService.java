package com.example.appdemo.network;

import com.example.appdemo.json_models.request.LoginSendForm;
import com.example.appdemo.json_models.response.UserInfor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface RetrofitService {
    @POST(APIStringRoot.LOGIN)
    @Headers({APIStringRoot.HEADER})
    Call<UserInfor> login(@Body LoginSendForm sendForm);
}
